"""
URL configuration for wastemanagement project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from myapp import views

urlpatterns = [
    path('login_get/',views.login_get),
    path('login_post/',views.login_post),
    path('adm_index_get/',views.adm_index_get),
    path('adm_add_waste_category_get/',views.adm_add_waste_category_get),
    path('adm_add_waste_category_post/',views.adm_add_waste_category_post),
    path('adm_verify_pickup_get/',views.adm_verify_pickup_get),
    path('approve_pickup/<id>',views.approve_pickup),
    path('reject_pickup/<id>',views.reject_pickup),
    path('adm_view_worker_get/',views.adm_view_worker_get),
    path('adm_view_user_category_get/',views.adm_view_user_category_get),
    path('adm_view_compliant_get/',views.adm_view_compliant_get),
    path('adm_add_waste_category_get/',views.adm_add_waste_category_get),
    path('adm_add_waste_category_post/',views.adm_add_waste_category_post),
    path('adm_view_waste_category_get/',views.adm_view_waste_category_get),
    path('adm_edit_waste_category_get/<id>',views.adm_edit_waste_category_get),
    path('delete_waste_category/<id>',views.delete_waste_category),
    path('adm_edit_waste_category_post/',views.adm_edit_waste_category_post),
    path('adm_view_feedback_get/',views.adm_view_feedback_get),
    path('adm_change_password_get/',views.adm_change_password_get),
    path('adm_change_password_post/',views.adm_change_password_post),
    path('adm_send_reply_get/<id>',views.adm_send_reply_get),
    path('adm_send_reply_post/',views.adm_send_reply_post),
    path('adm_verified_pickup_get/',views.adm_verified_pickup_get),
    path('adm_rejected_pickup_get/', views.adm_rejected_pickup_get),

    path('pickupindex_get/', views.pickupindex_get),
    path('pickup_register/', views.pickup_register),
    path('pickup_register_post/', views.pickup_register_post),
    path('pickup_viewprofile/', views.pickup_viewprofile),
    path('pickup_editprofile/', views.pickup_editprofile),
    path('pickup_editprofile_post/', views.pickup_editprofile_post),
    path('pickup_managestaff/', views.pickup_managestaff),
    path('pickup_managestaff_post/', views.pickup_managestaff_post),
    path('pickup_managesubarea/', views.pickup_managesubarea),
    path('pickup_managesubarea_post/', views.pickup_managesubarea_post),
    path('pickup_viewstafffeedback/', views.pickup_viewstafffeedback),
    path('pickup_viewwasterequest/', views.pickup_viewwasterequest),
    path('pickup_assignstaff/', views.pickup_assignstaff),
    path('pickup_assignstaff_post/', views.pickup_assignstaff_post),
    path('pickup_viewstatus/', views.pickup_viewstatus),
    path('pickup_managebill/', views.pickup_managebill),
    path('pickup_managebill_post/', views.pickup_managebill_post),
    path('pickup_changepassword/', views.pickup_changepassword),
    path('pickup_changepassword_post/', views.pickup_changepassword_post),
    path('pickup_chatwithuser/', views.pickup_chatwithuser),
    path('pickup_chatwithuser_post/', views.pickup_chatwithuser_post),






]
