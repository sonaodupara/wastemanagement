from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect


# Create your views here.
from myapp.models import *
from django.contrib.auth.models import User

def login_get(request):
    return render(request,'login.html')

def login_post(request):
    username=request.POST["username"]
    password=request.POST["password"]
    user=authenticate(request,username=username,password=password)
    if user is not None:
        login(request,user)
        if user.groups.filter(name="Admin").exists():
            return redirect('/myapp/adm_index_get/')
        elif user.groups.filter(name="Pickup").exists():
            return redirect('/myapp/pickupindex_get/')
        else:
            return redirect('/myapp/login_get/')
    else:
        return redirect('/myapp/login_get/')

def adm_index_get(request):
    return render(request,'adminpages/index.html')


def adm_verify_pickup_get(request):
    data=Pickup.objects.filter(Status='pending')
    return render(request,'adminpages/verify pickup.html',{'data':data})
def adm_verified_pickup_get(request):
    data=Pickup.objects.filter(Status='Approved')
    return render(request,'adminpages/verified pickup.html',{'data':data})

def adm_rejected_pickup_get(request):
    data=Pickup.objects.filter(Status='Rejected')
    return render(request,'adminpages/rejected pickup.html',{'data':data})

def approve_pickup(request,id):
    Pickup.objects.filter(id=id).update(Status="Approved")
    return redirect('/myapp/adm_verify_pickup_get/')

def reject_pickup(request,id):
    Pickup.objects.filter(id=id).update(Status="Rejected")
    return redirect('/myapp/adm_verify_pickup_get/')

def adm_view_worker_get(request):
    data=Staff.objects.all()
    return render(request,'adminpages/view worker.html',{'data':data})

def adm_view_user_category_get(request):
    data=Users.objects.all()
    return render(request,'adminpages/viewuser.html',{'data':data})

def adm_view_compliant_get(request):
    data=Complaint.objects.all()
    return render(request,'adminpages/view compliant.html',{'data':data})

def adm_add_waste_category_get(request):
    return render(request,'adminpages/Manage Waste Category.html')

def adm_add_waste_category_post(request):
    category=request.POST['category']
    type=request.POST['type']
    price=request.POST['price']

    obj=Category()
    obj.Category=category
    obj.Type=type
    obj.Price=price
    obj.save()

    return redirect('/myapp/adm_add_waste_category_get/')

def adm_view_waste_category_get(request):
    data=Category.objects.all()
    return render(request,'adminpages/View Waste Category.html',{"data":data})

def adm_edit_waste_category_get(request,id):
    data=Category.objects.get(id=id)
    return render(request,'adminpages/Edit Waste.html',{'data':data})

def adm_edit_waste_category_post(request):
    category = request.POST['category']
    type = request.POST['type']
    price = request.POST['Price']
    id = request.POST['id']

    obj = Category.objects.get(id=id)
    obj.Category = category
    obj.Type = type
    obj.Price = price
    obj.save()

    return redirect('/myapp/adm_view_waste_category_get/')

def delete_waste_category(request,id):
    Category.objects.get(id=id).delete()
    return redirect('/myapp/adm_view_waste_category_get/')


def adm_view_feedback_get(request):
    data=Feedback.objects.all()
    return render(request,'adminpages/viewfeedback.html',{'data':data})

def adm_change_password_get(request):
    return render(request,'adminpages/changepassword.html')

def adm_change_password_post(request):
    currentpass=request.POST['currentpass']
    newpass=request.POST['newpass']
    confirmpass=request.POST['confirmpass']
    user=request.user
    if user.check_password(currentpass):
        if newpass==confirmpass:
            user.set_password(newpass)
            user.save()
            return redirect('/myapp/login_get/')
        else:
            return redirect('/myapp/adm_change_password_get/')
    else:
        return redirect('/myapp/adm_change_password_get/')


def adm_send_reply_get(request,id):
    return render(request,'adminpages/Send reply.html',{'id':id})

def adm_send_reply_post(request):
    id = request.POST['id']
    reply= request.POST['reply']
    Complaint.objects.filter(id=id).update(Status="Replied",Reply=reply)
    return redirect("/myapp/adm_view_compliant_get/")



##-------------------------------------- P I C K U P ---------------------------------------------
def pickupindex_get(request):
    return render(request,'pickuppages/pickupindex.html')

def pickup_register(request):
    return render(request,'pickuppages/register.html')

def pickup_register_post(request):
    name = request.POST['name']
    logo = request.POST['logo']
    email = request.POST['email']
    phone = request.POST['phone']
    area = request.POST['area']
    tagline = request.POST['tagline']

    user=User.objects.create(username=email,password=make_password(phone))
    user.groups.add(Group.objects.get(name='Pickup'))
    user.save()

    data = Pickup()
    data.Name = name
    data.Logo = logo
    data.Email = email
    data.Phone = phone
    data.Tagline = tagline
    data.Status = 'pending'
    data.AREA_id= area
    data.AUTHUSER_id = user
    data.save()
    return

def pickup_viewprofile(request):
    return render(request,'pickuppages/view profile.html')

def pickup_editprofile(request):
    return render(request,'pickuppages/edit profile.html')

def pickup_editprofile_post(request):
    name = request.POST['name']
    logo = request.POST['logo']
    email = request.POST['email']
    phone = request.POST['phone']
    area = request.POST['area']
    tagline = request.POST['tagline']
    return


def pickup_managestaff(request):
    return render(request,'pickuppages/manage staff.html')

def pickup_managestaff_post(request):
    name = request.POST['name']
    photo = request.POST['photo']
    license = request.POST['license']
    dob = request.POST['dob']
    gender = request.POST['gender']
    email = request.POST['email']
    phone = request.POST['phone']
    subarea = request.POST['subarea']
    return

def pickup_managesubarea(request):
    return render(request,'pickuppages/manage subarea.html')

def pickup_managesubarea_post(request):
    area = request.POST['area']
    subarea = request.POST['subarea']
    return

def pickup_viewstafffeedback(request):
    return render(request,'pickuppages/view staff feedback.html')

def pickup_viewwasterequest(request):
    return render(request,'pickuppages/view waste req.html')

def pickup_assignstaff(request):
    return render(request,'pickuppages/assign staff.html')

def pickup_assignstaff_post(request):
    staff =request.POST['staff']
    return

def pickup_viewstatus(request):
    return render(request,'pickuppages/view status.html')

def pickup_managebill(request):
    return render(request,'pickuppages/manage bill.html')

def pickup_managebill_post(request):
    photo = request.POST['photo']
    return

def pickup_changepassword(request):
    return render(request,'pickuppages/change password.html')

def pickup_changepassword_post(request):
    currentpass = request.POST['currentpass']
    newpass = request.POST['newpass']
    confirmpass = request.POST['confirmpass']
    return

def pickup_chatwithuser(request):
    return render(request,'pickuppages/chat with user.html')

def pickup_chatwithuser_post(request):

    return



